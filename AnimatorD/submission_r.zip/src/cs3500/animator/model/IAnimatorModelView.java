package cs3500.animator.model;

import java.util.ArrayList;

public interface IAnimatorModelView {

  /**
   * Returns the scene as a String at Controller-specified time.
   *
   * @param time the time of the scene.
   */
  String snapshot(int time);

  /**
   * Getter for the anims field.
   *
   * @return this.anims
   */
  ArrayList<AbsAnimation> getAnims();

  /**
   * Getter for the shapes field.
   *
   * @return this.shapes
   */
  ArrayList<AbsMyShape> getShapes();

  /**
   * Give a description of this animator model.
   *
   * @return a string description of this animator model.
   */
  String describeAnimator();
}
