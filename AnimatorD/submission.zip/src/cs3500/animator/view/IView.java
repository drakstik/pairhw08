package cs3500.animator.view;

import cs3500.animator.model.IAnimatorModelView;

/**
 * Interface class for defining similar behavior across different views.
 * An IView displays the contents of its IAnimatorModelView, which it holds as a field.
 * The contents are "displayed", for example, on the screen, through System.out, or written
 * into a file.
 */
public interface IView {

  /**
   * Display this IView's model.
   */
  void display();

  /**
   * Change this IView's model field to that IAnimatorModelView.
   * @param model the model for this IView to use.
   */
  void setModel(IAnimatorModelView model);

  /**
   * Change this IView's tickrate to that.
   * @param tr the new tickrate.
   */
  void setTickrate(int tr);

  /**
   * Change this IView's to write its display to the given filePath.
   * @param output a String representing a filePath.
   * @throws RuntimeException if called on an IView that does not display to a file.
   */
  void setOutput(Appendable output) throws RuntimeException;
}
