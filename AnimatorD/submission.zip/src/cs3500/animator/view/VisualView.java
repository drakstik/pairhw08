package cs3500.animator.view;

import java.awt.Dimension;
import java.awt.BorderLayout;

import javax.swing.Timer;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.WindowConstants;

import cs3500.animator.model.AnimatorModel;
import cs3500.animator.model.IAnimatorModelView;

public class VisualView extends JFrame implements IView {

  private static final int DEFAULT_WINDOW_WIDTH = 1000;
  private static final int DEFAULT_WINDOW_HEIGHT = 1000;

  private IAnimatorModelView model;
  private double tickRate;
  AnimatorPanel panel;

  /**
   * Convinience Constructor.
   */
  public VisualView() {
    this.model = new AnimatorModel();
    tickRate = 1;
  }

  /**
   * Constructs a VisualView.
   *
   * @param model    the model.
   * @param tickRate tick per second.
   */
  public VisualView(IAnimatorModelView model, int tickRate) {
    this.model = model;
    this.tickRate = tickRate;
  }

  @Override
  public void display() {
    this.setTitle("Animator");
    this.setSize(DEFAULT_WINDOW_WIDTH, DEFAULT_WINDOW_HEIGHT);
    this.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

    this.setLayout(new BorderLayout());

    this.panel = new AnimatorPanel(model);
    panel.setPreferredSize(new Dimension(DEFAULT_WINDOW_WIDTH, DEFAULT_WINDOW_HEIGHT));
    JScrollPane scrollPane = new JScrollPane(panel);
    this.add(scrollPane, BorderLayout.CENTER);

    this.setVisible(true);

    int tickRateMS = ((Double) (1000 / tickRate))
            .intValue();
    Timer timer = new Timer(tickRateMS, panel);
    timer.start();
    while (true) {
      this.repaint();
    }
  }

  /**
   * Change this IView's model field to that IAnimatorModelView.
   */
  public void setModel(IAnimatorModelView model) {
    this.model = model;
    //this.panel.setModel(model);
  }

  /**
   * Change this IView's tickrate to that.
   *
   * @param tr the new tickrate.
   */
  public void setTickrate(int tr) {
    this.tickRate = tr;
  }

  public void setOutput(Appendable output) {
    throw new RuntimeException("Cannot set an output for a VisualView: always displays"
            + " to the screen.");
  }
}
