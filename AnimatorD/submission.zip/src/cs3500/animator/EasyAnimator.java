package cs3500.animator;

import cs3500.animator.model.AnimatorModel;
import cs3500.animator.model.ViewFactory;
import cs3500.animator.view.IView;
import cs3500.animator.view.SVGView;
import cs3500.animator.view.TextView;
import cs3500.animator.view.VisualView;
import util.AnimationFileReader;
import util.TweenModelBuilder;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 * Represents an easy animator with a main method that can run different animations.
 */
public final class EasyAnimator {

  /**
   * Begins the program.
   *
   * @param args these flags determine which animation to view and in what view, the output path of
   *             the program and the speed of the animation. command-line args will look like:
   *             <-if name-of-animation-file>
   *             <-iv type-of-view>
   *             <-o where-output-show-go>
   *             <-speed integer-ticks-per-second> .
   *
   *             with a space between each pairing.
   */
  // IMPORTANT: parsing breaks from the hasNext loop when it sees a "."
  // we could not figure out a better way of taking input, so please add a " ." to the end
  // of a test input to see our working program (svg and text DO print correctly to System.out)
  public static void main(String[] args) {
    ViewFactory vf = new ViewFactory();

    String animFileName = "";
    String viewType = "";
    String output = "";
    int tickRate = 1;

    Appendable ap = System.out;
    Scanner sc = new Scanner(System.in);

    while (sc.hasNext()) {
      //System.out.println("start parse");
      String arg = sc.next();
      if (arg.equals(".")) {
        break;
      }
      switch (arg) {
        case ("-if"):
          animFileName = sc.next();
          //System.out.println("filename = " + animFileName);
          break;
        case ("-iv"):
          //System.out.println("first arg");
          viewType = sc.next();
          //System.out.println("viewType = " + viewType);
          break;
        case ("-o"):
          output = sc.next();
          //System.out.println("output = " + output);
          break;
        case ("-speed"):
          tickRate = sc.nextInt();
          break;
        default:
          throw new IllegalArgumentException("Invalid command line input.");
          //TODO: Print error & ask for more input
      }
    }
    //System.out.println("Successful parse");

    if (animFileName.equals("") || viewType.equals("")) {
      throw new IllegalArgumentException("Input must include a view and a file path.");
    }

    AnimationFileReader afr = new AnimationFileReader();
    TweenModelBuilder<AnimatorModel> builder = new AnimatorModel.Builder();

    switch (viewType) {
      case ("svg"):
        //System.out.println("Made it into viewType switch");
        AnimatorModel svgModel = new AnimatorModel(); //all fields are empty ArrayLists
        if (!output.equals("") && !output.equals("out")) { //else leave ap as System.out
          //System.out.println("shouldn't get here");
          try {
            ap = new FileWriter(output);
          } catch (IOException e) {
            System.out.println("Internal IO error");
            break;
          }
        }

        try {
          //System.out.println("started try");
          svgModel = afr.readFile(animFileName, builder);
          //System.out.println(svgModel.describeAnimator());
        } catch (FileNotFoundException e) {
          System.out.println("Given filename invalid.");
          break;
        }

        //AnimatorModel svgModel = builder.build();
        IView svgV = vf.create("svg"); //need to write interface
        SVGView svgView = (SVGView) svgV;
        svgView.setModel(svgModel);
        svgView.setTickrate(tickRate);
        svgView.setOutput(ap);
        svgView.display();
        break;

      case ("visual"):
        AnimatorModel vModel = new AnimatorModel(); //all fields are empty ArrayLists
        try {
          vModel = afr.readFile(animFileName, builder);
        } catch (FileNotFoundException e) {
          System.out.println("Given filename invalid.");
          break;
        }

        //AnimatorModel vModel = builder.build();
        IView vv = vf.create("visual"); //need to write interface
        VisualView vView = (VisualView) vv;
        vView.setModel(vModel);
        System.out.println("visual view's model set");
        vView.setTickrate(tickRate);
        vView.display();
        System.out.println("visual view finished displaying");
        break;

      case ("text"):
        AnimatorModel tModel = new AnimatorModel(); //all fields are empty ArrayLists
        if (!output.equals("") && !output.equals("out")) { //else leave ap as System.out
          try {
            ap = new FileWriter(output);
          } catch (IOException e) {
            System.out.println("Internal IO error");
            break;
          }
        }

        try {
          tModel = afr.readFile(animFileName, builder);
        } catch (FileNotFoundException e) {
          System.out.println("Given filename invalid.");
          break;
        }

        //AnimatorModel tModel = builder.build();
        IView tV = vf.create("text"); //need to write interface
        TextView tView = (TextView) tV;
        tView.setModel(tModel);
        tView.setTickrate(tickRate);
        tView.setOutput(ap);
        tView.display();
        break;
      default:
        System.out.println("Given viewType invlaid!");
        break;
    }
  }
}
